package it.corso.alfasoft.Adapters;

public class Input {
}
