package it.corso.alfasoft.Domains;

public class Business {}