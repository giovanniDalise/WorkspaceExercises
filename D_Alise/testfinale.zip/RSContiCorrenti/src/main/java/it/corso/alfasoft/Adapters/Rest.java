package it.corso.alfasoft.Adapters;

public class Rest {
}
