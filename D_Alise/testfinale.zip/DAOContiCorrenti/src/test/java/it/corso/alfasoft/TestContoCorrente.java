package it.corso.alfasoft;

import it.corso.alfasoft.Dao.DaoContiCorrenti;
import it.corso.alfasoft.Dto.ContoCorrente;
import it.corso.alfasoft.exception.DaoException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;


public class TestContoCorrente{
    private static final String URL = "URL";
    private static final String USERNAME = "USERNAME";
    private static final String PASSWORD = "PASSWORD";
    private static final Logger logger = Logger.getLogger(TestContoCorrente.class.getName());
    private static String url;
    private static String username;
    private static String password;

    @BeforeAll
    public static void initTest() {
        TestContoCorrente.initVariables("./config.properties");
        TestContoCorrente.initDB("./testFinale.sql");
    }

    private static void initVariables(String s) {
        Properties p = new Properties();
        try(InputStream is = TestContoCorrente.class.getClassLoader().getResourceAsStream(s)){
            p.load(is);
            url = p.getProperty(URL);
            username = p.getProperty(USERNAME);
            password = p.getProperty(PASSWORD);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static void initDB(String s) {
        try(Connection c = DriverManager.getConnection(url, username, password)) {
            Statement stm = c.createStatement();
            InputStream is = TestContoCorrente.class.getClassLoader().getResourceAsStream(s);
            String initInstructions = "";
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = br.readLine()) != null){
                initInstructions += line;
            }
            String[] arrayInstr = initInstructions.split(";");
            for(int i = 0; i < arrayInstr.length; i++){
                stm.executeUpdate(arrayInstr[i]);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    public void testCreate(){
        DaoContiCorrenti dao = new DaoContiCorrenti();
        ContoCorrente contoCorrente = new ContoCorrente(638274635674L, "m", "234","435","Silvio","Cristiani","DGGVVN88H07F839S");
        Assertions.assertDoesNotThrow(
                () -> contoCorrente.setNumeroConto(dao.create(contoCorrente))
        );
        long numeroConto = contoCorrente.getNumeroConto();
        Assertions.assertTrue(
                numeroConto != 0,
                "errore di inserimento, il conto corrente inserito è null"
        );
    }
    @Test
    public void testGetBySurname() throws DaoException {
        DaoContiCorrenti dao = new DaoContiCorrenti();
        List<ContoCorrente> listaContoCorrenti = new ArrayList<>();
        listaContoCorrenti.add(new ContoCorrente(123456789123L,"f","123","456","Giovanni","Rossi","DLSGNN88H05F839S"));
        listaContoCorrenti.add(new ContoCorrente(987654321987L,"m","987","654","Gustavo", "Rossi","DLSGST88H05M830S"));
        String cognome = "Rossi";
        List<ContoCorrente> listaContiDao =dao.getByTextSur(cognome);
        Assertions.assertDoesNotThrow(()->dao.getByTextSur(cognome),"Errore nel metodo getByTextSur. Generata Exception");
        for(ContoCorrente contoCorrente: listaContoCorrenti){
            Assertions.assertTrue(listaContiDao.contains(contoCorrente),"Errore nel metodo getByTextSur. Dati non corretti");
        }
        for(ContoCorrente contoCorrente: listaContiDao){
            Assertions.assertTrue(listaContoCorrenti.contains(contoCorrente),"Errore nel metodo getByTextSur. Dati non corretti");
        }
    }
    @Test
    public void testGetByCF() throws DaoException {
        DaoContiCorrenti dao = new DaoContiCorrenti();
        ContoCorrente  contoCorrente = new ContoCorrente(123456789098L,"s","109","687","Geronimo", "Gerani", "DGGGNN88H09F839S");
        String cf = "DGGGNN88H09F839S";
        ContoCorrente contoDao =  dao.getByTextCF(cf);
        Assertions.assertDoesNotThrow(()->dao.getByTextCF(cf),"Errore nel metodo findById. Generata Exception");
        Assertions.assertEquals(dao.getByTextCF(cf),contoDao,"Errore nel metodo findById. Dati non corretti");
    }

}
