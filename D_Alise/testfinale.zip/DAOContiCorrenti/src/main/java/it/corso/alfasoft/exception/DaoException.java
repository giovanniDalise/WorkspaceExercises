package it.corso.alfasoft.exception;

public class DaoException extends Exception{
    public DaoException(String message){
        super(message);
    }
}
