package it.corso.alfasoft;

import it.corso.alfasoft.Dao.DaoContiCorrenti;
import it.corso.alfasoft.Dto.ContoCorrente;
import it.corso.alfasoft.exception.DaoException;

import java.util.List;
import java.util.Scanner;

public class App {

    private static DaoContiCorrenti daoContiCorrenti = new DaoContiCorrenti();

    public static void main( String[] args ) throws DaoException {

        Scanner input =  new Scanner (System.in);

        int scelta = 0;
        do {
            System.out.println("Scegli il tipo di operazione:");
            System.out.println("1.Inserisci un conto corrente");
            System.out.println("2.Cerca un conto corrente per cognome");
            System.out.println("3.Cerca un conto corrente per codice fiscale");

            scelta = input.nextInt();
            input.nextLine();

            switch (scelta){
                case 1:
                    creaContoCorrente(input);
                    break;
                case 2:
                    cercaContoPerCognome(input);
                    break;
                case 3:
                    cercaContoPerCodiceFiscale(input);
                    break;
                case 0:
                    System.out.println("Arrivederci");
                    break;
                default:
                    System.out.println("Scelta non valida riprova!");
                    break;
            }
        }while(scelta!=0);
    }

    public static void creaContoCorrente (Scanner input) throws DaoException{
        System.out.println("Inserisci il numero del conto corrente");
        long numeroContoCorrente = input.nextLong();
        input.nextLine();
        System.out.println("Inserisci il CIN");
        String CIN = input.nextLine();
        System.out.println("Inserici l'ABI");
        String ABI = input.nextLine();;
        System.out.println("Inserisci il CAB");
        String CAB = input.nextLine();
        System.out.println("Inserisci il nome del Titolare");
        String nomeTitolare = input.nextLine();
        System.out.println("Inserici il cognome del Titolare");
        String cognomeTitolare = input.nextLine();;
        System.out.println("Inserisci il codice fiscale del Titolare");
        String codiceFiscale = input.nextLine();
        long numeroContoCorrenteRestituito = daoContiCorrenti.create(new ContoCorrente(numeroContoCorrente,CIN,ABI,CAB,nomeTitolare,cognomeTitolare,codiceFiscale));
    }
    public static void cercaContoPerCognome(Scanner input) throws DaoException{
        System.out.println("Inserisci il cognome del titolare");
        String cognome = input.nextLine();
        List<ContoCorrente> listaContiCorrenti = daoContiCorrenti.getByTextSur(cognome);
        for(ContoCorrente contoCorrente: listaContiCorrenti){
            System.out.println(contoCorrente.toString());
        }
    }
    public static void cercaContoPerCodiceFiscale(Scanner input) throws DaoException{
        System.out.println("Inserisci il codice fiscale del titolare");
        String codiceFiscale = input.nextLine();
        ContoCorrente contoCorrente = daoContiCorrenti.getByTextCF(codiceFiscale);
        System.out.println(contoCorrente.toString());

    }

}



