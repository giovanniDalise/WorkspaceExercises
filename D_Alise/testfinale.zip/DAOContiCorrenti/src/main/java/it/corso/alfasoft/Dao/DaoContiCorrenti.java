package it.corso.alfasoft.Dao;

import it.corso.alfasoft.Dto.ContoCorrente;
import it.corso.alfasoft.exception.DaoException;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class DaoContiCorrenti implements IDao <ContoCorrente> {
    private static final String URL="URL";
    private static final String USERNAME="USERNAME";
    private static final String PASSWORD="PASSWORD";

    private String urlDB;
    private String username;
    private String password;


    private void setting() throws DaoException {
        Properties p=new Properties();
        try(InputStream input=getClass().getClassLoader().getResourceAsStream("./config.properties")){
            p.load(input);
            this.urlDB=p.getProperty(URL);
            this.username=p.getProperty(USERNAME);
            this.password=p.getProperty(PASSWORD);
        }catch(IOException e){
            throw new DaoException("Errore accesso al file config");
        }
    }
    protected Connection connect() throws DaoException {
        Connection c;
        try{
            if(this.urlDB==null){
                setting();
            }
            c= DriverManager.getConnection(urlDB,username,password);
        }catch(SQLException e){
            throw new DaoException(e.getMessage());
        }
        return c;
    }

    public long create (ContoCorrente nuovoConto) throws DaoException{
        try(Connection conn = connect()){
            PreparedStatement stm = conn.prepareStatement("Insert into ContoCorrente (numeroConto, CIN, ABI, CAB, nomeTitolare, cognomeTitolare, CodiceFiscaleTitolare) values (?,?,?,?,?,?,?);");

            stm.setLong(1,nuovoConto.getNumeroConto());
            stm.setString(2, nuovoConto.getCIN());
            stm.setString(3,nuovoConto.getABI());
            stm.setString(4,nuovoConto.getCAB());
            stm.setString(5,nuovoConto.getNomeTitolare());
            stm.setString(6,nuovoConto.getCognomeTitolare());
            stm.setString(7,nuovoConto.getCodiceFiscaleTitolare());

            int righeInserite = stm.executeUpdate();

        }catch (SQLException e){
            e.printStackTrace();
        }
        return nuovoConto.getNumeroConto();
    }

    public List<ContoCorrente> getByTextSur (String cognome) throws DaoException{
        List<ContoCorrente> result = new ArrayList<>();
        try(Connection conn = connect()){
            PreparedStatement ps = conn.prepareStatement("Select * from ContoCorrente Where cognomeTitolare = ?;");
            ps.setString(1,cognome);

            ResultSet rst = ps.executeQuery();
            long numeroContoCorrente = 0;
            String CIN = null;
            String ABI = null;
            String CAB = null;
            String nomeTitolare = null;
            String cognomeTitolare = null;
            String codiceFiscaleTitolare = null;
            while (rst.next()){
                numeroContoCorrente = rst.getLong("numeroConto");
                CIN = rst.getString("CIN");
                ABI = rst.getString("ABI");
                CAB = rst.getString("CAB");
                nomeTitolare = rst.getString("nomeTitolare");
                cognomeTitolare = rst.getString("cognomeTitolare");
                codiceFiscaleTitolare = rst.getString("codiceFiscaleTitolare");
                ContoCorrente contoCorrente = new ContoCorrente(numeroContoCorrente,CIN,ABI,CAB,nomeTitolare,cognomeTitolare,codiceFiscaleTitolare);
                result.add(contoCorrente);
            }

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return result;
    }

    public ContoCorrente getByTextCF (String codiceFiscale) throws DaoException{
        ContoCorrente contoCorrente = null;
        try(Connection conn = connect()){
            PreparedStatement ps = conn.prepareStatement("Select * from ContoCorrente Where codiceFiscaleTitolare = ?;");
            ps.setString(1,codiceFiscale);

            ResultSet rst = ps.executeQuery();

            if(rst.next()){
                long numeroContoCorrente = rst.getLong("numeroConto");
                String CIN = rst.getString("CIN");
                String ABI = rst.getString("ABI");
                String CAB = rst.getString("CAB");
                String nomeTitolare = rst.getString("nomeTitolare");
                String cognomeTitolare = rst.getString("cognomeTitolare");
                String codiceFiscaleTitolare = rst.getString("codiceFiscaleTitolare");
                contoCorrente = new ContoCorrente(numeroContoCorrente,CIN,ABI,CAB,nomeTitolare,cognomeTitolare,codiceFiscaleTitolare);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return contoCorrente;
    }
}
