package it.corso.alfasoft.Dao;

import it.corso.alfasoft.exception.DaoException;

import java.util.List;

public interface IDao <T>{
   // List<T> read() throws DaoException;
    long create (T element) throws DaoException;
    List<T> getByTextSur(String text) throws DaoException;
    T getByTextCF(String text) throws DaoException;

}
