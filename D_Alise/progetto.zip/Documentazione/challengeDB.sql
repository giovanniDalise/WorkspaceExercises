Create database challenge;
use challenge;
create table domande(
    domandaId bigint not null auto_increment,
    testoDomanda varchar (300) not null,
primary key(domandaId)
);

create table risposte(
    rispostaId bigint not null auto_increment,
    domanda bigint not null,
    testoRisposta varchar (3000) not null,
    esito boolean not null,
    foreign key (domanda) REFERENCES domande(domandaId),
primary key(rispostaId)
);
    
    
    
    