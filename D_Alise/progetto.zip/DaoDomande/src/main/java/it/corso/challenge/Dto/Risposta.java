package it.corso.challenge.Dto;

import java.util.Objects;

public class Risposta {
    private long rispostaId;
    private Domanda domanda;
    private String testoRisposta;
    private boolean esito;

    public Risposta(long rispostaId, Domanda domanda, String testoRisposta, boolean esito) {
        this.rispostaId = rispostaId;
        this.domanda = domanda;
        this.testoRisposta = testoRisposta;
        this.esito = esito;
    }

    public long getRispostaId() {
        return rispostaId;
    }

    public void setRispostaId(long rispostaId) {
        this.rispostaId = rispostaId;
    }

    public Domanda getDomanda() {
        return domanda;
    }

    public void setDomanda(Domanda domanda) {
        this.domanda = domanda;
    }

    public String getTestoRisposta() {
        return testoRisposta;
    }

    public void setTestoRisposta(String testoRisposta) {
        this.testoRisposta = testoRisposta;
    }

    public boolean isEsito() {
        return esito;
    }

    public void setEsito(boolean esito) {
        this.esito = esito;
    }

    @Override
    public String toString() {
        return "Risposta{" +
                "rispostaId=" + rispostaId +
                ", domanda=" + domanda +
                ", testoRisposta='" + testoRisposta + '\'' +
                ", esito=" + esito +
                '}';
    }
}
