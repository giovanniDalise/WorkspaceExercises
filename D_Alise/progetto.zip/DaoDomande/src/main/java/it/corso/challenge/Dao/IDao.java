package it.corso.challenge.Dao;

import it.corso.challenge.exception.DaoException;

import java.util.List;

    public interface IDao <T>{

        List<T> read() throws DaoException;

        long create (T element) throws DaoException;

        T getById (long id) throws DaoException;

        List<T> getByObject (T element) throws DaoException;

}
