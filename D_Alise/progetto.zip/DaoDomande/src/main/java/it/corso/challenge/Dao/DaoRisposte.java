package it.corso.challenge.Dao;


import it.corso.challenge.Dto.Domanda;
import it.corso.challenge.Dto.Risposta;
import it.corso.challenge.exception.DaoException;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class DaoRisposte {
    private static final String URL="URL";
    private static final String USERNAME="USERNAME";
    private static final String PASSWORD="PASSWORD";

    private String urlDB;
    private String username;
    private String password;


    private void setting() throws DaoException {
        Properties p=new Properties();
        try(InputStream input=getClass().getClassLoader().getResourceAsStream("./config.properties")){
            p.load(input);
            this.urlDB=p.getProperty(URL);
            this.username=p.getProperty(USERNAME);
            this.password=p.getProperty(PASSWORD);
        }catch(IOException e){
            throw new DaoException("Errore accesso al file config");
        }
    }
    protected Connection connect() throws DaoException{
        Connection c;
        try{
            if(this.urlDB==null){
                setting();
            }
            c= DriverManager.getConnection(urlDB,username,password);
        }catch(SQLException e){
            throw new DaoException(e.getMessage());
        }
        return c;
    }
    public List<Risposta> read() throws DaoException {
        List<Risposta> listaRisposte = new ArrayList<>();

        try (Connection conn = this.connect()) {
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT rispostaId, domanda, testoRisposta, esito, testoDomanda FROM risposte JOIN domande  ON domanda = domandaId;");
            while (rs.next()) {
                long id = rs.getLong("rispostaId");
                long domandaId = rs.getLong("domanda");
                String testoRisposta = rs.getString("testoRisposta");
                boolean esito = rs.getBoolean("esito");
                String testoDomanda = rs.getString("testoDomanda");

                Domanda domandaAssociata = new Domanda(domandaId, testoDomanda);

                listaRisposte.add(new Risposta(id, domandaAssociata, testoRisposta, esito));
            }
        } catch (SQLException sql) {
            sql.printStackTrace();
        }
        return listaRisposte;
    }

    public long create (Risposta nuovaRisposta) throws DaoException{
        long id = 0;
        try(Connection conn = this.connect()){
            PreparedStatement stm = conn.prepareStatement("Insert into risposte (domanda, testoRisposta, esito) values (?,?,?); ",Statement.RETURN_GENERATED_KEYS);

            stm.setLong(1,nuovaRisposta.getDomanda().getDomandaId());
            stm.setString(2,nuovaRisposta.getTestoRisposta());
            stm.setBoolean(3,nuovaRisposta.isEsito());

            int righeInserite = stm.executeUpdate();

            ResultSet rs = stm.getGeneratedKeys();
            if (rs.next()){
                id = rs.getLong(1);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return id;
    }



    public List<Risposta> getByObject(Risposta risposta) throws DaoException {
        List<Risposta> listaRisposte = new ArrayList<>();
        try (Connection conn = connect()) {
            String query = "SELECT rispostaId, domanda, testoRisposta, esito, testoDomanda FROM risposte JOIN domande  ON domanda = domandaId  WHERE domanda = ?";

            PreparedStatement ps = conn.prepareStatement(query);
            ps.setLong(1,risposta.getDomanda().getDomandaId());

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                long id = rs.getLong("rispostaId");
                long idDomanda = rs.getLong("domanda");
                String testoRisposta = rs.getString("testoRisposta");
                boolean esito = rs.getBoolean("esito");
                String testoDomanda = rs.getString("testoDomanda");
                Domanda domanda = new Domanda(idDomanda,testoDomanda);

                listaRisposte.add(new Risposta(id, domanda, testoRisposta, esito));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaRisposte;
    }
    public Risposta getById(long id) throws DaoException{
        Risposta risposta = null;
        try(Connection conn = connect()){
            PreparedStatement ps = conn.prepareStatement("SELECT rispostaId, domanda, testoRisposta, esito, testoDomanda FROM risposte JOIN domande  ON domanda = domandaId where rispostaId = ?;");
            ps.setLong(1,id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                long idRisposta = rs.getLong("rispostaId");
                long domandaId = rs.getLong("domanda");
                String testoRisposta = rs.getString("testoRisposta");
                boolean esito = rs.getBoolean("esito");
                String testoDomanda = rs.getString("testoDomanda");

                Domanda domandaAssociata = new Domanda(domandaId, testoDomanda);
                risposta = new Risposta(idRisposta, domandaAssociata, testoRisposta, esito);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return risposta;
    }
}
