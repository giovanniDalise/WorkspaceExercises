package it.corso.challenge.Dto;

import java.util.Objects;

public class Domanda {
    private long domandaId;
    private String testoDomanda;

    public Domanda(long domandaId, String testoDomanda) {
        this.domandaId = domandaId;
        this.testoDomanda = testoDomanda;
    }

    public long getDomandaId() {
        return domandaId;
    }

    public String getTestoDomanda() {
        return testoDomanda;
    }

    public void setDomandaId(long domandaId) {
        this.domandaId = domandaId;
    }

    public void setTestoDomanda(String testoDomanda) {
        this.testoDomanda = testoDomanda;
    }

    @Override
    public String toString() {
        return "Domanda{" +
                "domandaId=" + domandaId +
                ", testoDomanda='" + testoDomanda + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Domanda domanda = (Domanda) o;
        return domandaId == domanda.domandaId && Objects.equals(testoDomanda, domanda.testoDomanda);
    }
}
