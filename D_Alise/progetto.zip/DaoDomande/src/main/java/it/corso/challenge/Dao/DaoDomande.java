package it.corso.challenge.Dao;

import it.corso.challenge.Dto.Domanda;
import it.corso.challenge.Dto.Risposta;
import it.corso.challenge.exception.DaoException;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class DaoDomande implements IDao<Domanda> {
    private static final String URL="URL";
    private static final String USERNAME="USERNAME";
    private static final String PASSWORD="PASSWORD";

    private String urlDB;
    private String username;
    private String password;


    private void setting() throws DaoException {
        Properties p=new Properties();
        try(InputStream input=getClass().getClassLoader().getResourceAsStream("./config.properties")){
            p.load(input);
            this.urlDB=p.getProperty(URL);
            this.username=p.getProperty(USERNAME);
            this.password=p.getProperty(PASSWORD);
        }catch(IOException e){
            throw new DaoException("Errore accesso al file config");
        }
    }
    protected Connection connect() throws DaoException{
        Connection c;
        try{
            if(this.urlDB==null){
                setting();
            }
            c= DriverManager.getConnection(urlDB,username,password);
        }catch(SQLException e){
            throw new DaoException(e.getMessage());
        }
        return c;
    }
    public List<Domanda> read()throws DaoException{
        List<Domanda> listaDomande = new ArrayList<>();
        try(Connection conn = this.connect()){
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("Select * from domande;");
            while(rs.next()){
                long id = rs.getLong("domandaId");
                String testoDomanda = rs.getString("testoDomanda");

                listaDomande.add(new Domanda(id,testoDomanda));
            }
        }catch(SQLException sql){
            sql.printStackTrace();
        }
        return listaDomande;
    }
    public long create (Domanda nuovaDomanda) throws DaoException{
        long id = 0;
        try(Connection conn = this.connect()){
            PreparedStatement stm = conn.prepareStatement("Insert into domande (testoDomanda) values (?); ",Statement.RETURN_GENERATED_KEYS);

            stm.setString(1,nuovaDomanda.getTestoDomanda());

            int righeInserite = stm.executeUpdate();

            ResultSet rs = stm.getGeneratedKeys();
            if (rs.next()){
                id = rs.getLong(1);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return id;
    }
    public Domanda getById(long id) throws DaoException{
        Domanda domanda = null;
        try(Connection conn = connect()){
            PreparedStatement ps = conn.prepareStatement("select * from domande where domandaId = ?;");
            ps.setLong(1,id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                domanda = new Domanda(rs.getLong("domandaId"), rs.getString("testoDomanda"));
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return domanda;
    }
    public List<Domanda> getByObject (Domanda element) throws DaoException{
        List<Domanda> listaDomande = new ArrayList<Domanda>();
        return listaDomande;
    }

}
