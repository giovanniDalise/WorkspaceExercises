package it.corso.challenge.exception;

public class DaoException extends Exception{
    public DaoException(String message){
        super(message);
    }
}

