package it.corso.challenge;

import it.corso.challenge.Dao.DaoDomande;
import it.corso.challenge.Dao.DaoRisposte;
import it.corso.challenge.Dto.Domanda;
import it.corso.challenge.Dto.Risposta;
import it.corso.challenge.exception.DaoException;

import java.util.Scanner;


public class Docente {
    private static DaoDomande daoDomanda = new DaoDomande();
    private static DaoRisposte daoRisposte = new DaoRisposte();

    public static void main(String[] args) throws DaoException{

        Scanner input =  new Scanner (System.in);

        int scelta = 0;
            do {
            System.out.println("Scegli il tipo di operazione:");
            System.out.println("1.Inserisci una domanda");
            System.out.println("2.Inserisci una risposta");
            System.out.println("0.Esci");

            scelta = input.nextInt();
            input.nextLine();

            switch (scelta){
                case 1:
                    inserisciDomanda(input);
                    break;
                case 2:
                    inserisciRisposta(input);
                    break;
                case 0:
                    System.out.println("Arrivederci");
                    break;
                default:
                    System.out.println("Scelta non valida riprova!");
                    break;
            }
        }while(scelta!=0);
}

    public static void inserisciDomanda(Scanner input) throws DaoException {
        System.out.println("Inserisci l'id della domanda");
        long idFittizio = input.nextLong();
        input.nextLine();
        System.out.println("Inserisci il testo della domanda");
        String testoDomanda = input.nextLine();
        long idDomandaAutogenerato = daoDomanda.create(new Domanda(idFittizio, testoDomanda));
    }

    public static void inserisciRisposta(Scanner input) throws DaoException {
        System.out.println("Inserisci l'id della risposta");
        long idFittizio = input.nextLong();
        input.nextLine();
        System.out.println("Inserisci l'id della domanda associata");
        long idDomandaAssociata = input.nextLong();
        input.nextLine();
        String testoDomanda = daoDomanda.getById(idDomandaAssociata).getTestoDomanda();
        Domanda domandaAssociata = new Domanda(idDomandaAssociata,testoDomanda);
        System.out.println("Inserisci il testo della risposta");
        String testoRisposta = input.nextLine();
        System.out.println("Inserisci l'esito della risposta");
        boolean esito = input.nextBoolean();
        long idDomandaAutogenerato = daoRisposte.create(new Risposta(idFittizio, domandaAssociata, testoRisposta, esito));
    }
}

