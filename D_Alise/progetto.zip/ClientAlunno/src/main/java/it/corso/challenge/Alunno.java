package it.corso.challenge;

import it.corso.challenge.Dao.DaoDomande;
import it.corso.challenge.Dao.DaoRisposte;
import it.corso.challenge.Dto.Domanda;
import it.corso.challenge.Dto.Risposta;
import it.corso.challenge.exception.DaoException;

import java.util.List;
import java.util.Scanner;

public class Alunno {
    private static DaoDomande daoDomanda = new DaoDomande();

    private static DaoRisposte daoRisposte = new DaoRisposte();

    public static void main(String[] args) throws DaoException {

        Scanner input =  new Scanner (System.in);

        int scelta = 0;
        do {
            System.out.println("Scegli il tipo di operazione:");
            System.out.println("1.Rispondi alle domande");
            System.out.println("0.Esci");

            scelta = input.nextInt();
            input.nextLine();

            switch (scelta){
                case 1:
                    rispondiDomande(input);
                    break;
                case 0:
                    System.out.println("Arrivederci");
                    break;
                default:
                    System.out.println("Scelta non valida riprova!");
                    break;
            }
        }while(scelta!=0);
    }
    public static void rispondiDomande(Scanner input) throws DaoException {
        System.out.println("Domande:");
        List<Domanda> listaDomande = daoDomanda.read();
        for(Domanda domanda : listaDomande) {
            System.out.println(domanda.toString());
        }
        System.out.println("Inserisci l'id della domanda a cui vuoi rispondere:");
        long idDomanda = input.nextLong();
        input.nextLine();
        String testoDomanda = daoDomanda.getById(idDomanda).getTestoDomanda();
        Domanda domanda = new Domanda(idDomanda,testoDomanda);
        Risposta rispostaFiltro = new Risposta(0,domanda,"",false);
        List<Risposta> listaRisposte = daoRisposte.getByObject(rispostaFiltro);
        System.out.println("Seleziona la risposta esatta:");
        for(Risposta risposta : listaRisposte){
            System.out.println("ID risposta:" + risposta.getRispostaId());
            System.out.println(risposta.getTestoRisposta());
        }
        System.out.println("Inserisci l'id della risposta giusta:");
        long idRispostaScelta = input.nextLong();
        Risposta rispostaScelta = daoRisposte.getById(idRispostaScelta);
        if(rispostaScelta.isEsito()){
            System.out.println("Risposta corretta");
        }else {
            System.out.println("Risposta errata");
        }
    }
}
